import { Injectable } from '@nestjs/common';
import { Storage } from '@google-cloud/storage';

@Injectable()
export class FileService {
  async upload({ files }) {
    const waitedFiles = await Promise.all(files);

    const storage = new Storage({
      projectId: 'bustling-tuner-352601',
      keyFilename: 'gcp-file-storage.json',
    }).bucket('jjoony_bucket');

    const results = await Promise.all(
      waitedFiles.map((el) => {
        return new Promise((resolve, reject) => {
          el.createReadStream()
            .pipe(storage.file(el.filename).createWriteStream())
            .on('finish', () => resolve(`jjoony_bucket/${el.filename}`))
            .on('error', () => reject('실패'));
        });
      }),
    );
    return results;
  }
}
